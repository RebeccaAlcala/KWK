//
//  profile.swift
//  HiveConnect
//
//  Created by Rebecca Alcala on 5/24/24.
//

import SwiftUI

struct profile: View {
    @State private var navigateToTasks = false
    
    var body: some View {
        VStack{
            Text("Welcome to your hive!")
            .font(.largeTitle)
            .foregroundColor(.white)
            .padding()
            
            // Task Manager Section
            VStack {
                Text("Task Manager")
                    .font(.headline)
                    .foregroundColor(.white)
                Button(action: {
                    self.navigateToTasks = true
                }) {
                    Text("View Tasks")
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
            }
            .padding()
            
            // Friends List Section
            VStack {
                Text("Friends List")
                .font(.headline)
                .foregroundColor(.white)
                // Placeholder for friends list
                Text("Friend 1")
                    .foregroundColor(.white)
                Text("Friend 2")
                    .foregroundColor(.white)
                Text("Friend 3")
                    .foregroundColor(.white)
            }
            .padding()
            .background(Color.yellow)
            .edgesIgnoringSafeArea(.all)
            .navigationDestination(isPresented: $navigateToTasks) {tasks()}
            
            
        }
        
    }
}

#Preview {
    profile()
}
