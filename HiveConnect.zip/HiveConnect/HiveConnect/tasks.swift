//
//  tasks.swift
//  HiveConnect
//
//  Created by Rebecca Alcala on 5/24/24.
//

import SwiftUI

struct Task: Identifiable {
    let id = UUID()
    var subject: String
    var description: String
    var deadline: Date
}


struct tasks: View {
    
    @State private var tasks: [Task] = []
    @State private var showAddTaskView = false
    
    var body: some View {
        NavigationView {
                    VStack {
                        List(tasks) { task in
                            VStack(alignment: .leading) {
                                Text(task.subject)
                                    .font(.headline)
                                Text(task.description)
                                    .font(.subheadline)
                                Text("Deadline: \(task.deadline, formatter: dateFormatter)")
                                    .font(.caption)
                            }
                            .padding(.vertical, 5)
                        }
                        
                        Button(action: {
                            showAddTaskView = true
                        }) {
                            Text("Add Task")
                                .padding()
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(8)
                        }
                        .padding()
                        .sheet(isPresented: $showAddTaskView) {
                            AddTaskView(tasks: $tasks)
                        }
                    }
                    .navigationBarTitle("Your Tasks")
                }
            }
        }

        struct AddTaskView: View {
            @Environment(\.presentationMode) var presentationMode
            @Binding var tasks: [Task]
            
            @State private var subject: String = ""
            @State private var description: String = ""
            @State private var deadline: Date = Date()
            
            var body: some View {
                NavigationView {
                    Form {
                        Section(header: Text("Task Details")) {
                            TextField("Class Subject", text: $subject)
                            TextField("Description", text: $description)
                            DatePicker("Deadline", selection: $deadline, displayedComponents: .date)
                    }
                        
                    Button(action: {
                        let newTask = Task(subject: subject, description: description, deadline: deadline)
                            tasks.append(newTask)
                            presentationMode.wrappedValue.dismiss()
                    }) {
                        
                    Text("Save Task")
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                    }
                        
                    .disabled(subject.isEmpty || description.isEmpty)
                }
                .navigationBarTitle("Add New Task", displayMode: .inline)
            }
        }
    }

    private let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        return formatter
    }()

    struct TasksView_Previews: PreviewProvider {
        static var previews: some View {
        tasks()
    }
}
