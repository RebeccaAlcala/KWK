//
//  HiveConnectApp.swift
//  HiveConnect
//
//  Created by Rebecca Alcala on 5/24/24.
//

import SwiftUI

@main
struct HiveConnectApp: App {
    var body: some Scene {
        WindowGroup {
            Login()
        }
    }
}
