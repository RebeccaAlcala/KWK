//
//  Login.swift
//  HiveConnect
//
//  Created by Rebecca Alcala on 5/24/24.
//

import SwiftUI

struct Login: View {
    @State private var username: String = UserDefaults.standard.string(forKey: "username") ?? ""
    @State private var password: String = UserDefaults.standard.string(forKey: "password") ?? ""
    @State private var navigateToProfile = false
    
    var body: some View {
        VStack {
            Image("logo")
                .resizable(resizingMode: .stretch)
                .aspectRatio(contentMode: .fit)
            
            TextField("Enter username", text: $username)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            TextField("Enter password", text: $password)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
                Button(action: {
                    UserDefaults.standard.set(self.username, forKey: "username")
                    UserDefaults.standard.set(self.password, forKey: "password")
                    print("Username saved: \(self.username)")
                    print("Password saved: \(self.password)")
                    self.navigateToProfile = true
                }) {
                    
                    Text("Login")
                        .padding()
                        .background(Color.yellow)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                .navigationDestination(isPresented: $navigateToProfile) {
                                    profile()
                
                
            }
            .padding()
            
            }
        }
    }
    struct Login_Previews: PreviewProvider {
        static var previews: some View {
            Login()
        }
    }

