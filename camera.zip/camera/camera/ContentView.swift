//
//  ContentView.swift
//  camera
//
//  Created by Rebecca Alcala on 5/23/24.
//

import SwiftUI

struct ContentView: View {
    
    @State var isImagePickerShowing = false
    @State var selectedImage: UIImage?
    @State private var sourceType:
    UIImagePickerController.SourceType = .photoLibrary
    
    var body: some View {
        VStack {
            Image(uiImage: selectedImage ?? UIImage(named: "projectPic")!)
                .resizable(resizingMode: .stretch)
                .aspectRatio(contentMode: .fit)
            
            HStack {
                Button("Select a Photo") {
                    self.sourceType = .photoLibrary
                    isImagePickerShowing = true
                }
                .padding()
                Button("Take a Photo") {
                    self.sourceType = .camera
                    isImagePickerShowing = true
                }
                .padding()
            }
        }
        .sheet(isPresented: $isImagePickerShowing) {
                    ImagePicker(selectedImage: $selectedImage, isImagePickerShowing: $isImagePickerShowing, sourceType: self.sourceType)
                }
        .padding()
    }
}

#Preview {
    ContentView()
}
